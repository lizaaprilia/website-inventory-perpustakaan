<?php
include('config.php');

// Menangkap ID peminjaman yang dikembalikan
if (isset($_GET['id'])) {
    $id_peminjaman = $_GET['id'];

    // Query untuk mendapatkan informasi peminjaman berdasarkan ID
    $sql = "SELECT p.*, b.judul FROM peminjaman p 
            JOIN buku b ON p.id_buku = b.id 
            WHERE p.id = $id_peminjaman";
    $result = $conn->query($sql);
    $peminjaman = $result->fetch_assoc();
}

// Proses pengembalian buku
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_peminjaman = $_POST['id_peminjaman'];
    $tanggal_pengembalian = date('Y-m-d');

    // Update tabel peminjaman
    $sql = "UPDATE peminjaman SET tanggal_pengembalian = '$tanggal_pengembalian' WHERE id = $id_peminjaman";
    if ($conn->query($sql) === TRUE) {
        $id_buku = $peminjaman['id_buku'];
        $sql = "UPDATE buku SET jumlah = jumlah + 1 WHERE id = $id_buku";
        $conn->query($sql);

        echo "<script>alert('Buku berhasil dikembalikan!'); window.location='daftar_buku.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengembalian Buku</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');

        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #8e2de2, #4a00e0);
            color: #fff;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        h2 {
            margin-top: 40px;
            font-size: 36px;
            letter-spacing: 1px;
        }

        .form-container {
            background: rgba(255, 255, 255, 0.95);
            color: #333;
            padding: 30px;
            margin-top: 30px;
            border-radius: 15px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.25);
            width: 100%;
            max-width: 450px;
        }

        .form-group {
            margin-bottom: 20px;
            text-align: left;
        }

        .form-group label {
            font-weight: 600;
            display: block;
            margin-bottom: 8px;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 16px;
            background-color: #f9f9f9;
        }

        .form-container button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(to right, #8e2de2, #4a00e0);
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }

        .form-container button:hover {
            background: linear-gradient(to right, #4a00e0, #8e2de2);
        }

        .info {
            margin-bottom: 25px;
            text-align: left;
        }

        .info p {
            margin: 6px 0;
            font-size: 16px;
        }

        @media (max-width: 600px) {
            .form-container {
                margin: 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>

    <h2>Pengembalian Buku</h2>
    <div class="form-container">
        <form method="POST">
            <input type="hidden" name="id_peminjaman" value="<?php echo $peminjaman['id']; ?>">

            <div class="info">
                <p><strong>Judul Buku:</strong> <?php echo $peminjaman['judul']; ?></p>
                <p><strong>Nama Peminjam:</strong> <?php echo $peminjaman['nama_peminjam']; ?></p>
            </div>

            <div class="form-group">
                <label for="tanggal_pengembalian">Tanggal Pengembalian</label>
                <input type="date" name="tanggal_pengembalian" value="<?php echo date('Y-m-d'); ?>" required>
            </div>

            <button type="submit">Kembalikan Buku</button>
        </form>
    </div>

</body>
</html>
