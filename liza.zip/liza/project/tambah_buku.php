<?php
include('config.php');

// Proses form jika ada data POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $jumlah = $_POST['jumlah'];

    // Validasi input
    if (empty($judul) || empty($pengarang) || empty($jumlah)) {
        echo "<script>alert('Semua field harus diisi!');</script>";
    } else {
        // Query untuk menambah buku
        $sql = "INSERT INTO buku (judul, pengarang, jumlah) VALUES ('$judul', '$pengarang', $jumlah)";
        
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Buku berhasil ditambahkan!'); window.location='daftar_buku.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }
}

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Buku | Perpustakaan</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
    body {
        font-family: 'Roboto', sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to bottom right, #6a11cb, #2575fc);
        color: white;
        text-align: center;
    }

    header {
        background-color: rgba(0, 0, 0, 0.6);
        padding: 50px 20px 30px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
    }

    h1 {
        font-size: 36px;
        text-transform: uppercase;
        text-shadow: 2px 2px 6px rgba(0, 0, 0, 0.5);
        margin-bottom: 10px;
    }

    p {
        font-size: 18px;
        margin-top: 0;
        color: #f0f0f0;
    }

    .menu {
        text-align: center;
        margin-top: 20px;
    }

    .menu a {
        padding: 12px 24px;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        color: white;
        text-decoration: none;
        border-radius: 8px;
        margin: 5px;
        display: inline-block;
        transition: all 0.3s ease;
    }

    .menu a:hover {
        background: linear-gradient(to right, #4a00e0, #8e2de2);
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    }

    .form-container {
        width: 100%;
        max-width: 400px;
        margin: 40px auto;
        background-color: rgba(255, 255, 255, 0.1);
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    }

    .form-container h2 {
        margin-bottom: 20px;
        color: #ffffff;
        font-size: 28px;
    }

    .form-container label {
        display: block;
        text-align: left;
        margin-bottom: 5px;
        margin-top: 15px;
        font-weight: 500;
        color: #e0e0e0;
    }

    .form-container input {
        width: 100%;
        padding: 12px;
        font-size: 16px;
        border-radius: 5px;
        border: none;
        background-color: rgba(255, 255, 255, 0.9);
        color: #2c3e50;
        box-sizing: border-box;
    }

    .form-container button {
        width: 100%;
        padding: 14px;
        margin-top: 20px;
        font-size: 16px;
        font-weight: bold;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        border: none;
        border-radius: 6px;
        color: white;
        cursor: pointer;
        transition: background 0.3s ease, transform 0.2s;
    }

    .form-container button:hover {
        background: linear-gradient(to right, #4a00e0, #8e2de2);
        transform: scale(1.03);
    }

    footer {
        background-color: rgba(0, 0, 50, 0.8);
        color: white;
        padding: 20px;
        text-align: center;
        margin-top: 50px;
        font-size: 14px;
    }

    @media (max-width: 768px) {
        .form-container {
            margin: 20px;
            padding: 20px;
        }

        .menu a {
            display: block;
            margin: 10px auto;
            width: 80%;
        }
    }
</style>

</head>
<body>
    <header>
        <h1>Perpustakaan Sekolah</h1>
        <p>Tambah Buku Baru</p>
    </header>

    <div class="menu">
        <a href="index.php">Kembali ke Halaman Utama</a> |
        <a href="daftar_buku.php">Lihat Daftar Buku</a>
    </div>

    <div class="form-container">
        <h2>Tambah Buku</h2>
        <form method="POST">
            <label for="judul">Judul Buku:</label>
            <input type="text" id="judul" name="judul" required><br>
            
            <label for="pengarang">Pengarang Buku:</label>
            <input type="text" id="pengarang" name="pengarang" required><br>
            
            <label for="jumlah">Jumlah Buku:</label>
            <input type="number" id="jumlah" name="jumlah" required><br>

            <button type="submit">Tambah Buku</button>
        </form>
    </div>

    <footer>
        <p>&copy; 2025 Perpustakaan Sekolah. All rights reserved.</p>
    </footer>
</body>
</html>
