<?php
include('config.php');

// Query untuk mengambil data peminjaman
$sql = "SELECT p.*, b.judul FROM peminjaman p JOIN buku b ON p.id_buku = b.id WHERE p.tanggal_pengembalian IS NULL";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Peminjaman Buku</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        table, th, td { border: 1px solid black; }
        th, td { padding: 10px; text-align: left; }
        h2 { color: #2c3e50; }
        .button { padding: 10px 15px; background-color: #3498db; color: white; text-decoration: none; border-radius: 5px; }
        .button:hover { background-color: #2980b9; }
    </style>
</head>
<body>
    <h2>Daftar Peminjaman Buku</h2>
    <table>
        <tr>
            <th>ID Peminjaman</th>
            <th>Judul Buku</th>
            <th>Nama Peminjam</th>
            <th>Tanggal Pinjam</th>
            <th>Tanggal Kembali</th>
            <th>Aksi</th>
        </tr>
        <?php while($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['judul']; ?></td>
                <td><?php echo $row['nama_peminjam']; ?></td>
                <td><?php echo $row['tanggal_pinjam']; ?></td>
                <td><?php echo $row['tanggal_kembali']; ?></td>
                <td><a href="kembalikan_buku.php?id=<?php echo $row['id']; ?>" class="button">Kembalikan</a></td>
            </tr>
        <?php } ?>
    </table>
</body>
</html>
