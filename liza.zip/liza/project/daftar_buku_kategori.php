<?php
// Aktifkan laporan error
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "perpustakaan";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Validasi input kategori_id
if (!isset($_GET['kategori_id']) || !is_numeric($_GET['kategori_id'])) {
    echo "<p>ID kategori tidak valid.</p>";
    exit;
}

$kategori_id = $_GET['kategori_id'];

// Ambil informasi kategori
$sql_kategori = "SELECT * FROM kategori WHERE id = ?";
$stmt_kategori = $conn->prepare($sql_kategori);
$stmt_kategori->bind_param("i", $kategori_id);
$stmt_kategori->execute();
$result_kategori = $stmt_kategori->get_result();

if ($result_kategori->num_rows === 0) {
    echo "<p>Kategori tidak ditemukan.</p>";
    exit;
}

$kategori = $result_kategori->fetch_assoc();

// Ambil buku berdasarkan kategori
$sql_buku = "SELECT * FROM buku WHERE kategori_id = ?";
$stmt_buku = $conn->prepare($sql_buku);
$stmt_buku->bind_param("i", $kategori_id);
$stmt_buku->execute();
$result_buku = $stmt_buku->get_result();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Buku Berdasarkan Kategori</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 20px;
            background: linear-gradient(to right, #8e2de2, #4a00e0);
            color: white;
        }

        h1 {
            text-align: center;
            color: #fff;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: rgba(255, 255, 255, 0.95);
            color: #333;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }

        th, td {
            padding: 15px;
            border-bottom: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #6c5ce7;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f3f3f3;
        }

        .back-btn {
            display: inline-block;
            margin-top: 30px;
            padding: 12px 24px;
            background-color: #6c5ce7;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            transition: background-color 0.3s ease;
        }

        .back-btn:hover {
            background-color: #4a00e0;
        }
    </style>
</head>
<body>

    <h1>Buku dalam Kategori: <?php echo htmlspecialchars($kategori['nama_kategori']); ?></h1>

    <?php if ($result_buku->num_rows > 0): ?>
        <table>
            <tr>
                <th>Judul Buku</th>
                <th>Pengarang</th>
                <th>Tahun</th>
            </tr>
            <?php while($row = $result_buku->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['judul']); ?></td>
                    <td><?php echo htmlspecialchars($row['pengarang']); ?></td>
                    <td><?php echo htmlspecialchars($row['tahun']); ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>Tidak ada buku dalam kategori ini.</p>
    <?php endif; ?>

    <a href="kategori_buku.php" class="back-btn">← Kembali ke Daftar Kategori</a>

</body>
</html>

<?php
// Tutup koneksi
$conn->close();
?>
