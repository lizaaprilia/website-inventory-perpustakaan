<?php
include('config.php');

// Menangkap ID buku yang akan diedit
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk mengambil data buku berdasarkan ID
    $sql = "SELECT * FROM buku WHERE id = $id";
    $result = $conn->query($sql);

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
    } else {
        echo "Buku tidak ditemukan!";
        exit;
    }
}

// Proses update buku jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $judul = $_POST['judul'];
    $pengarang = $_POST['pengarang'];
    $jumlah = $_POST['jumlah'];

    // Validasi input
    if (empty($judul) || empty($pengarang) || empty($jumlah)) {
        echo "<script>alert('Semua field harus diisi!');</script>";
    } else {
        // Query untuk mengupdate data buku
        $sql = "UPDATE buku SET judul = '$judul', pengarang = '$pengarang', jumlah = $jumlah WHERE id = $id";

        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Buku berhasil diperbarui!'); window.location='daftar_buku.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Buku | Perpustakaan</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
        /* Styling untuk tampilan yang lebih baik dengan gradasi ungu-biru */
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to bottom right, #8e2de2, #4a00e0); /* Gradasi ungu-biru */
            color: white;
            text-align: center;
        }

        /* Header */
        header {
            background-color: rgba(0, 0, 0, 0.7); /* Transparan hitam */
            padding: 40px 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
            margin-bottom: 30px;
        }

        h1 {
            font-size: 36px;
            letter-spacing: 1px;
            text-transform: uppercase;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.6); /* Bayangan untuk teks */
        }

        p {
            font-size: 18px;
            font-weight: 400;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.5);
        }

        /* Form Container */
        .form-container {
            width: 100%;
            max-width: 400px;
            margin: 40px auto;
            background-color: rgba(194, 113, 212, 0.9); /* Transparan putih */
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #2c3e50;
            font-size: 28px;
            letter-spacing: 1px;
        }

        /* Styling form input and button */
        .form-container input,
        .form-container button {
            width: 100%;
            padding: 12px;
            margin: 12px 0;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ddd;
            box-sizing: border-box;
            background-color:rgb(230, 185, 251); /* Background input */
        }

        .form-container button {
            background-color: #8e2de2; /* Gradasi ungu */
            color: white;
            border: none;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .form-container button:hover {
            background-color: #4a00e0; /* Gradasi biru */
        }

        /* Responsive Design for mobile */
        @media (max-width: 768px) {
            .form-container {
                padding: 15px;
            }
        }

    </style>
</head>
<body>

    <header>
        <h1>Perpustakaan Sekolah</h1>
        <p>Edit Buku</p>
    </header>

    <div class="form-container">
        <h2>Form Edit Buku</h2>
        <form method="POST">
            <label for="judul">Judul Buku:</label>
            <input type="text" id="judul" name="judul" value="<?php echo $row['judul']; ?>" required><br>

            <label for="pengarang">Pengarang Buku:</label>
            <input type="text" id="pengarang" name="pengarang" value="<?php echo $row['pengarang']; ?>" required><br>

            <label for="jumlah">Jumlah Buku:</label>
            <input type="number" id="jumlah" name="jumlah" value="<?php echo $row['jumlah']; ?>" required><br>

            <button type="submit">Perbarui Buku</button>
        </form>
    </div>

</body>
</html>
