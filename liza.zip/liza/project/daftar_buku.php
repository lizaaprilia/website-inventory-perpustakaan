<?php 
include('config.php');

// Mengambil data buku dari database
$sql = "SELECT * FROM buku";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Buku</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <style>
    body {
        font-family: 'Roboto', sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to bottom right, #6a11cb, #2575fc); /* Gradasi ungu-biru */
        color: #ffffff;
    }

    header {
        background-color: rgba(0, 0, 0, 0.5);
        padding: 50px 20px 30px;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
    }

    h1 {
        margin: 0;
        font-size: 36px;
        font-weight: 600;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);
    }

    p {
        font-size: 18px;
        color: #f0f0f0;
    }

    .menu {
        text-align: center;
        margin-top: 20px;
    }

    .menu a {
        padding: 12px 24px;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        color: white;
        text-decoration: none;
        border-radius: 8px;
        margin: 5px;
        transition: all 0.3s ease;
        display: inline-block;
    }

    .menu a:hover {
        background: linear-gradient(to right, #4a00e0, #8e2de2);
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.3);
    }

    form {
        text-align: center;
        margin: 30px 0;
    }

    input[type="text"] {
        padding: 10px 15px;
        font-size: 16px;
        border-radius: 5px;
        border: none;
        width: 40%;
        max-width: 400px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
    }

    button {
        padding: 10px 20px;
        background: linear-gradient(to right, #6a11cb, #2575fc);
        color: white;
        border: none;
        border-radius: 5px;
        margin-left: 10px;
        cursor: pointer;
        transition: background 0.3s;
    }

    button:hover {
        background: linear-gradient(to right, #2575fc, #6a11cb);
    }

    table {
        width: 90%;
        margin: 20px auto;
        border-collapse: collapse;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 10px rgba(0,0,0,0.3);
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th {
        background: linear-gradient(to right, #7f00ff, #e100ff);
        color: white;
        padding: 14px;
    }

    td {
        padding: 12px;
        background-color: rgba(255, 255, 255, 0.1);
        color: #ffffff;
    }

    tr:hover td {
        background-color: rgba(255, 255, 255, 0.2);
    }

    .button {
        padding: 10px 15px;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        color: white;
        text-decoration: none;
        border-radius: 6px;
        margin: 2px;
        display: inline-block;
        transition: background 0.3s, transform 0.2s;
    }

    .button:hover {
        background: linear-gradient(to right, #4a00e0, #8e2de2);
        transform: scale(1.05);
    }

    .disabled {
        background-color: #777;
        cursor: not-allowed;
    }

    footer {
        background-color: rgba(0, 0, 50, 0.8);
        color: white;
        padding: 20px;
        text-align: center;
        margin-top: 50px;
        font-size: 14px;
    }

    @media (max-width: 768px) {
        .menu a {
            display: block;
            margin: 10px auto;
            width: 80%;
        }

        input[type="text"], button {
            width: 80%;
            margin: 10px 0;
        }

        table {
            width: 95%;
        }
    }
</style>

</head>
<body>

    <header>
        <h1>Perpustakaan Sekolah</h1>
        <p>Daftar Buku yang Tersedia</p>
    </header>

    <div class="menu">
        <a href="index.php">Kembali ke Halaman Utama</a> |
        <a href="tambah_buku.php">Tambah Buku</a>
    </div>

    <form method="GET">
        <input type="text" name="search" placeholder="Cari Buku..." value="<?php echo isset($_GET['search']) ? $_GET['search'] : ''; ?>">
        <button type="submit">Cari</button>
    </form>

    <?php
    $search = isset($_GET['search']) ? $_GET['search'] : '';
    $sql = "SELECT * FROM buku WHERE judul LIKE '%$search%' OR pengarang LIKE '%$search%'";
    $result = $conn->query($sql);
    ?>

    <table>
        <tr>
            <th>ID</th>
            <th>Judul</th>
            <th>Pengarang</th>
            <th>Jumlah</th>
            <th>Aksi</th>
        </tr>

        <?php while($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?php echo $row['id']; ?></td>
                <td><?php echo $row['judul']; ?></td>
                <td><?php echo $row['pengarang']; ?></td>
                <td><?php echo $row['jumlah']; ?></td>
                <td>
                    <a href="edit_buku.php?id=<?php echo $row['id']; ?>" class="button">Edit</a>
                    <a href="hapus_buku.php?id=<?php echo $row['id']; ?>" class="button" onclick="return confirm('Apakah Anda yakin ingin menghapus buku ini?')">Hapus</a>
                    <a href="pinjam_buku.php?id=<?php echo $row['id']; ?>" class="button">Pinjam</a>
                    <a href="kembali_buku.php?id=<?php echo $row['id']; ?>" class="button">Kembalikan</a>
                </td>
            </tr>
        <?php } ?>
    </table>

    <footer>
        <p>&copy; 2025 Perpustakaan Sekolah. All rights reserved.</p>
    </footer>

</body>
</html>
