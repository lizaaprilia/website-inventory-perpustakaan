<?php
include('config.php');

// Mengambil ID buku yang akan dihapus
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Query untuk menghapus buku berdasarkan ID
    $sql = "DELETE FROM buku WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Buku berhasil dihapus!'); window.location='daftar_buku.php';</script>";
    } else {
        echo "<script>alert('Error: " . $conn->error . "');</script>";
    }
} else {
    echo "<script>alert('ID buku tidak ditemukan!'); window.location='daftar_buku.php';</script>";
}

?>
