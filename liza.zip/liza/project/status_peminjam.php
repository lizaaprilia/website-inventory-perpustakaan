<?php
// Aktifkan tampilan error untuk debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Koneksi ke database
$servername = "localhost";
$username = "root"; // Ganti dengan username MySQL Anda
$password = ""; // Ganti dengan password MySQL Anda
$dbname = "perpustakaan"; // Ganti dengan nama database Anda

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query untuk mengambil data peminjaman
$sql = "SELECT buku.judul, peminjaman.tanggal_pinjam, peminjaman.tanggal_kembali 
        FROM peminjaman 
        INNER JOIN buku ON peminjaman.id_buku = buku.id 
        WHERE peminjaman.status = 'Dipinjam'";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Status Peminjaman</title>
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 20px;
        background: linear-gradient(to bottom right, #6a11cb, #2575fc);
        color: #ffffff;
    }

    h1 {
        text-align: center;
        color: #ffffff;
        text-shadow: 1px 1px 3px rgba(0,0,0,0.3);
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        background-color: rgba(255, 255, 255, 0.1);
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 8px rgba(0,0,0,0.2);
    }

    th, td {
        padding: 14px;
        text-align: left;
        color: #fff;
    }

    th {
        background: linear-gradient(to right, #7f00ff, #e100ff);
    }

    tr:nth-child(even) {
        background-color: rgba(255, 255, 255, 0.05);
    }

    tr:hover {
        background-color: rgba(255, 255, 255, 0.15);
    }

    a {
        display: inline-block;
        padding: 12px 24px;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        color: white;
        text-decoration: none;
        border-radius: 8px;
        margin-top: 30px;
        text-align: center;
        transition: background 0.3s ease;
    }

    a:hover {
        background: linear-gradient(to right, #4a00e0, #8e2de2);
    }
</style>

</head>
<body>
    <h1>Status Peminjaman Buku</h1>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <tr>
                <th>Judul Buku</th>
                <th>Tanggal Pinjam</th>
                <th>Tanggal Kembali</th>
            </tr>
            <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['judul']; ?></td>
                    <td><?php echo $row['tanggal_pinjam']; ?></td>
                    <td><?php echo $row['tanggal_kembali']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
    <?php else: ?>
        <p>Tidak ada buku yang dipinjam saat ini.</p>
    <?php endif; ?>

    <a href="index.php">Kembali ke Menu Utama</a>
</body>
</html>

<?php
// Tutup koneksi
$conn->close();
?>
