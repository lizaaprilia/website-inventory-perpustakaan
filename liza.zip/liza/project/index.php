<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perpustakaan Sekolah</title>
    <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        background: linear-gradient(to bottom right, #6a11cb, #2575fc);
        color: #ffffff;
        text-align: center;
    }

    h1 {
        padding: 40px 20px 10px;
        font-size: 36px;
        letter-spacing: 1.5px;
        text-transform: uppercase;
        color: #ffffff;
        text-shadow: 2px 2px 8px rgba(0, 0, 0, 0.3);
    }

    p {
        font-size: 18px;
        margin: 10px 20px 30px;
        color: #f0f0f0;
    }

    a {
        padding: 12px 24px;
        background: linear-gradient(to right, #8e2de2, #4a00e0);
        color: white;
        text-decoration: none;
        border-radius: 8px;
        margin: 10px;
        font-size: 18px;
        display: inline-block;
        transition: all 0.3s ease;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    a:hover {
        background: linear-gradient(to right, #4a00e0, #8e2de2);
        transform: translateY(-3px);
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
    }

    .content {
        padding: 60px 20px 100px;
    }

    .menu {
        position: fixed;
        bottom: 0;
        width: 100%;
        background-color: rgba(0, 0, 50, 0.8);
        padding: 15px 0;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.4);
    }

    .menu a {
        margin: 10px 15px;
        text-align: center;
        transition: background 0.3s ease;
    }

    .menu a:hover {
        background: linear-gradient(to right, #4a00e0, #8e2de2);
    }

    @media (max-width: 768px) {
        .menu {
            flex-direction: column;
            align-items: center;
        }

        .menu a {
            width: 80%;
        }
    }
</style>

</head>
<body>
    <div class="content">
        <h1>Selamat datang di Perpustakaan SMK PGRI 2 Taman</h1>
        <p>Di sini, Anda bisa mengakses berbagai buku dan informasi mengenai perpustakaan kami.</p>
        <a href="daftar_buku.php">Mulai Menjelajah</a>
    </div>

    <div class="menu">
        <a href="daftar_buku.php">Lihat Daftar Buku</a>
        <a href="tambah_buku.php">Tambah Buku Baru</a>
        <a href="status_peminjam.php">Status Peminjaman</a>
    </div>
</body>
</html>
