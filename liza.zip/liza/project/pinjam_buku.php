<?php 
include('config.php');

// Menangkap ID buku yang dipinjam
if (isset($_GET['id'])) {
    $id_buku = $_GET['id'];

    // Query untuk mengambil data buku berdasarkan ID
    $sql = "SELECT * FROM buku WHERE id = $id_buku";
    $result = $conn->query($sql);
    $buku = $result->fetch_assoc();
}

// Proses pinjam buku
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_buku = $_POST['id_buku'];
    $nama_peminjam = $_POST['nama_peminjam'];
    $tanggal_pinjam = date('Y-m-d');
    $tanggal_kembali = $_POST['tanggal_kembali'];

    // Validasi jumlah buku yang tersedia
    $sql = "SELECT jumlah FROM buku WHERE id = $id_buku";
    $result = $conn->query($sql);
    $buku = $result->fetch_assoc();
    if ($buku['jumlah'] <= 0) {
        echo "<script>alert('Buku tidak tersedia!');</script>";
    } else {
        // Kurangi jumlah buku yang tersedia
        $sql = "UPDATE buku SET jumlah = jumlah - 1 WHERE id = $id_buku";
        $conn->query($sql);

        // Simpan peminjaman buku ke tabel peminjaman
        $sql = "INSERT INTO peminjaman (id_buku, nama_peminjam, tanggal_pinjam, tanggal_kembali) 
                VALUES ($id_buku, '$nama_peminjam', '$tanggal_pinjam', '$tanggal_kembali')";
        
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Buku berhasil dipinjam!'); window.location='daftar_buku.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Peminjaman Buku</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(to bottom right, #8e2de2, #4a00e0); /* Gradasi ungu-biru */
            color: white;
            text-align: center;
        }

        h2 {
            color: #fff;
            font-size: 36px;
            letter-spacing: 1px;
            margin-top: 30px;
        }

        .form-container {
            width: 100%;
            max-width: 400px;
            margin: 50px auto;
            background-color: rgba(255, 255, 255, 0.9); /* Transparan putih */
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.3);
        }

        .form-container input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ddd;
            box-sizing: border-box;
            background-color: #f1f1f1; /* Background input */
        }

        .form-container button {
            width: 100%;
            padding: 12px;
            background-color: #8e2de2; /* Gradasi ungu */
            color: white;
            font-size: 16px;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .form-container button:hover {
            background-color: #4a00e0; /* Gradasi biru */
        }

        /* Styling untuk form label */
        .form-container label {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            text-align: left;
            margin-bottom: 5px;
        }

        /* Responsiveness */
        @media (max-width: 768px) {
            .form-container {
                padding: 20px;
            }
        }

    </style>
</head>
<body>

    <h2>Peminjaman Buku</h2>
    <div class="form-container">
        <form method="POST">
            <input type="hidden" name="id_buku" value="<?php echo $buku['id']; ?>">

            <label for="nama_peminjam">Nama Peminjam:</label>
            <input type="text" name="nama_peminjam" required><br><br>

            <label for="tanggal_kembali">Tanggal Kembali:</label>
            <input type="date" name="tanggal_kembali" required><br><br>

            <button type="submit">Pinjam Buku</button>
        </form>
    </div>

</body>
</html>
