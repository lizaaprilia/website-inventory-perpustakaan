<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "perpustakaan";

$conn = new mysqli($servername, $username, $password, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Ambil kategori buku
$sql = "SELECT * FROM kategori ORDER BY nama_kategori ASC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategori Buku</title>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap');

        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(135deg, #6a11cb, #2575fc);
            color: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            min-height: 100vh;
        }

        h1 {
            margin-top: 50px;
            font-size: 36px;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }

        ul.kategori {
            list-style: none;
            padding: 0;
            margin-top: 30px;
            width: 90%;
            max-width: 600px;
        }

        ul.kategori li {
            margin: 15px 0;
            padding: 18px;
            background: rgba(255, 255, 255, 0.15);
            border-radius: 12px;
            backdrop-filter: blur(6px);
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        ul.kategori li:hover {
            transform: scale(1.03);
            background: rgba(255, 255, 255, 0.25);
        }

        ul.kategori li a {
            text-decoration: none;
            color: #fff;
            font-size: 18px;
            font-weight: 600;
            display: block;
        }

        ul.kategori li a:hover {
            text-shadow: 1px 1px 3px #000;
        }

        .back-button {
            margin-top: 40px;
            padding: 12px 24px;
            background: linear-gradient(to right, #8e2de2, #4a00e0);
            color: #fff;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.3s ease;
        }

        .back-button:hover {
            background: linear-gradient(to right, #4a00e0, #8e2de2);
        }

        @media (max-width: 600px) {
            h1 {
                font-size: 28px;
            }
            ul.kategori li a {
                font-size: 16px;
            }
        }
    </style>
</head>
<body>

    <h1>Kategori Buku</h1>

    <?php if ($result && $result->num_rows > 0): ?>
        <ul class="kategori">
            <?php while($row = $result->fetch_assoc()): ?>
                <li>
                    <a href="daftar_buku_kategori.php?kategori_id=<?php echo htmlspecialchars($row['id']); ?>">
                        <?php echo htmlspecialchars($row['nama_kategori']); ?>
                    </a>
                </li>
            <?php endwhile; ?>
        </ul>
    <?php else: ?>
        <p style="text-align: center; margin-top: 20px;">Belum ada kategori buku yang tersedia.</p>
    <?php endif; ?>

    <a class="back-button" href="index.php">← Kembali ke Menu Utama</a>

</body>
</html>

<?php $conn->close(); ?>
